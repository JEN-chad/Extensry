export const images = [
    {
        image: "https://i.ibb.co/MkMBtqLd/1330845.png",
    },
    {
        image: "https://i.ibb.co/cmYjdpm/1343747.png",
    },
    {
        image: "https://i.ibb.co/p6rvLZRw/d0ef70fd28dad32d2ba97477fb7a9f99.png",
    },
    {
        image: "https://i.ibb.co/rG0kY4zZ/12666487.png",
    },
    {
        image: "https://i.ibb.co/39qSHHLd/illustration-anime-city.jpg",
    },
]